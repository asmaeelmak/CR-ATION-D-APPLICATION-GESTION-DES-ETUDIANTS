#ifndef SECDIALOG_H
#define SECDIALOG_H

#include <QDialog>
#include <QObject>

namespace Ui {
class SecDialog;
}

class SecDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SecDialog(QWidget *parent = nullptr);
    ~SecDialog();

private slots:

    void on_pushButtonSUPPRIMER_PREMIERe_LIGNE_clicked(); // 10

    void on_pushButtonAJOUTER_clicked(); //5

   void on_listWidget_currentRowChanged(int currentRow);

   void on_pushButton_15_clicked();

   void on_pushButton_16_clicked();

   void on_pushButton_8_clicked();

private:
    Ui::SecDialog *ui;
     QString file_path;
};

#endif // SECDIALOG_H
