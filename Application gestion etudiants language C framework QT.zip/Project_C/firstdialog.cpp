#include "firstdialog.h"
#include "ui_firstdialog.h"
#include "secdialog.h"

FirstDialog::FirstDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FirstDialog)
{
    ui->setupUi(this);
    setWindowTitle("Menu");
}

FirstDialog::~FirstDialog()
{
    delete ui;
}

void FirstDialog::on_buttonBox_accepted()
{
    SecDialog SecDialog;
    SecDialog.setModal(true);
    SecDialog.exec();
} // pour passer a la gestion des listes on tape OK

