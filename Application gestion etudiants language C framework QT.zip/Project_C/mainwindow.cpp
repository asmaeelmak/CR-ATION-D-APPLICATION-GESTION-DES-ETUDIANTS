#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "secdialog.h"
#include "firstdialog.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Login Window");
    ui->lineEdit->setPlaceholderText("user");
    ui->lineEdit_2->setPlaceholderText("Password");
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
    ui->lineEdit->setClearButtonEnabled(true);
    ui->lineEdit_2->setClearButtonEnabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QString username = ui->lineEdit->text(); //pour lire le login
     QString password = ui->lineEdit_2->text(); //lire le MDP

     QFile file("C:/Qt/monlogin.bin");

     if(file.open(QIODevice::WriteOnly | QIODevice::Text)){
        QTextStream ecriture(&file);
        ecriture<<"login : "+username+" ";
        ecriture<<"mdp : "+password;
        file.close();
// LOGIN et MDP sauvegardé dans le fichier qu'on a nommé monlogin.bin (comme il est mentionné on veut qu'on enregistre les logins des utilisateurs)
}

 QMessageBox::information(this,"login","username and password saved");// alert pour dire a l'utilisateur que son login est bien enregistré
  QTextStream stream (&file); //pour afficher le fichier

}

void MainWindow::ecritureFichier(){

}// pour ecrire dans le fichier







void MainWindow::on_pushButton_2_clicked()
{
    FirstDialog FirstDialog;
    FirstDialog.setModal(true);
    FirstDialog.exec();
} // MENU BUTTON


