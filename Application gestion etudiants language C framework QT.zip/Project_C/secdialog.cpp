#include "secdialog.h"
#include "ui_secdialog.h"
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QMessageBox>
#include <QTextEdit>

SecDialog::SecDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SecDialog)
{
    ui->setupUi(this);
    setWindowTitle("Gestion des étudiants");
    ui->lineEdit->setPlaceholderText("CNE");
    ui->lineEdit_2->setPlaceholderText("Gestion Etudiant");
    ui->lineEdit_3->setPlaceholderText("30");
}

SecDialog::~SecDialog()
{
    delete ui;
}

void SecDialog::on_pushButtonAJOUTER_clicked()
{
    QString str= ui->lineEdit_5->text();
    if(str=="")
    return;
    ui->listWidget->addItem(str);
    QString str1= ui->lineEdit_6->text();
    if(str1=="")
    return;
    ui->listWidget->addItem(str1);
    QString str2= ui->lineEdit_7->text();
    if(str2=="")
    return;
    ui->listWidget->addItem(str2);
     QString str3= ui->lineEdit_8->text();
    if(str3=="")
    return;
    ui->listWidget->addItem(str3);
}
// pour AJOUETER un etudiant à la liste ( apres il faut que la liste sera dans une ligne pas en colonne)






void SecDialog::on_pushButtonSUPPRIMER_PREMIERe_LIGNE_clicked()
{
    QString i,j,k,l;
    i=ui->lineEdit->text();
    j=ui->lineEdit_2->text();
    k=ui->lineEdit_3->text();
    l=ui->lineEdit_4->text();
    ui->listWidget->item(0)->setText(i);
    ui->listWidget->item(1)->setText(j);
    ui->listWidget->item(2)->setText(k);
     ui->listWidget->item(3)->setText(l);
}

// commande pour supprimer la premiere ligne de la liste jusqu'au present (apres il faut qu'on supprime l'etudiant ajouté)




void SecDialog::on_pushButton_16_clicked() //PARCOURIR FROM .TXT FILE
{
    QString file_name = QFileDialog::getOpenFileName(this,"Open the file");
    QFile file(file_name);
    file_path=file_name;
    if(!file.open(QFile::ReadOnly | QFile:: Text)) {
        QMessageBox::warning(this,"..","file not open");
        return;
    }
    QTextStream in(&file);
    QString st = in.readLine();
    ui->listWidget->addItem(st);
    file.close();
}

/* void SecDialog::on_pushButton_15_clicked() //EXPORTER VERS .TXT FILE
{
     QString file_name = QFileDialog::getSaveFileName(this,"Open the file");
    QFile file(file_path);
    file_path=file_name;
    if(!file.open(QFile::WriteOnly | QFile:: Text)) {
        QMessageBox::warning(this,"..","file not open");
        return;
    }
    QTextStream out(&file);


    QString text =ui->listWidget->takeItem(text
                                           );

    out<<"text : "+text; " ";



    file.flush();
    file.close();

}*/






